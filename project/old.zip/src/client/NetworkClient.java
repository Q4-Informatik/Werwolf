package client;

public class NetworkClient {

    private Socket socket;
    private InputStream inputStream;
    private OutputStream outputStream;

    public void connect(String host, int port) {
        socket = new Socket();
    }

}