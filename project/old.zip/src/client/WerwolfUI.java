package client;

public class WerwolfUI extends JFrame {

    public static void main(String[] args) {
        (new WerwolfUI()).show();
    }

    public void show() {
        setSize(600, 800);
        setTitle("Werwolf");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

}