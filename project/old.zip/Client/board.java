import javax.swing.*;

public class board extends JPanel {
    /**
     *
     */
    private static final long serialVersionUID = 7964367118694647896L;

    public board() {

    }
}