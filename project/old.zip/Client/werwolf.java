import javax.swing.*;
import java.net.*;
import java.io.*;
import java.awt.*;

public class werwolf extends JFrame {
    /**
     *
     */
    private static final long serialVersionUID = 7815814534460942224L;

    static String ip;
    static int port = 12345;
    static String tosend = "test";

    public werwolf() {
        initPort();
        initUI();
    }

    private void initPort() {
        ip = JOptionPane.showInputDialog(null, "Adresse des Hosts:", "Porteingabe", JOptionPane.PLAIN_MESSAGE);
    }

    private void initUI() {
        add(new board());
        setSize(1920, 1080);
        setTitle("Werwolf");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    public static void main(String[] args) throws IOException {
        EventQueue.invokeLater(() -> {
            werwolf prg = new werwolf();
            prg.setVisible(true);
        });

        // String ip = "localhost";
        // String port = "12345";

        Thread cn = new Thread(new connection());
        cn.start();

    }
}

class connection implements Runnable {
    public void run() {
        try {
            Socket socket = new Socket(werwolf.ip, werwolf.port);
            DataInputStream dis = new DataInputStream(socket.getInputStream());
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

            while (true) {
                if (dis.readUTF() == "end") {
                    break;
                }
                System.out.println(dis.readUTF());

                if (werwolf.tosend != null) {
                    dos.writeUTF(werwolf.tosend);
                    werwolf.tosend = null;
                }

            }

            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * void send(String[] args) throws IOException { String ip = args[0]; int port =
     * Integer.parseInt(args[1]); String msg = args[2];
     * 
     * System.out.println("Connecting..."); Socket s = new Socket(ip, port);
     * 
     * PrintWriter printWriter = new PrintWriter(new
     * OutputStreamWriter(s.getOutputStream())); printWriter.print(msg);
     * printWriter.flush(); }
     */

    /*
     * void connect(String[] args) throws IOException { String serverName = args[0];
     * int port = Integer.parseInt(args[1]);
     * 
     * System.out.println("Connecting to " + serverName + "at" + port); Socket s =
     * new Socket(serverName, port);
     * 
     * System.out.println("Connected to " + s.getRemoteSocketAddress());
     * OutputStream outToServer = s.getOutputStream(); DataOutputStream out = new
     * DataOutputStream(outToServer);
     * 
     * InputStream inFromServer = s.getInputStream(); DataInputStream in = new
     * DataInputStream(inFromServer);
     * 
     * }
     * 
     * void close() { // s.close(); this.close(); }
     * 
     * void send(String msg) throws IOException { out.writeUTF(msg); }
     */
    /*
     * void send(String msg) throws IOException { PrintWriter printWriter = new
     * PrintWriter(new OutputStreamWriter(s.getOutputStream()));
     * printWriter.print(msg); printWriter.flush(); }
     * 
     * String receive() throws IOException { BufferedReader bufferedReader = new
     * BufferedReader(new InputStreamReader(s.getInputStream())); char[] buffer =
     * new char[200]; int anzahlZeichen = bufferedReader.read(buffer, 0, 200);
     * String msg = new String(buffer, 0, anzahlZeichen); return msg; }
     */
}
